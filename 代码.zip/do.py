import pandas as pd
import numpy as np
# 加载数据集
data = pd.read_csv(r'D:\datasets\GeneratedLabelledFlows\TrafficLabelling_\2.csv')
print(data[' Label'].value_counts())
print(data.info())
# 查看数据的前几行，检查数据的结构
print(data.head())

# 处理标签列中的缺失值
data[' Label'] = data[' Label'].fillna('unknown')
data_cleaned = data.dropna()

# 将标签列转换为数值（0: 正常流量, 1: 攻击流量）
from sklearn.preprocessing import LabelEncoder

label_encoder = LabelEncoder()
data[' Label'] = label_encoder.fit_transform(data[' Label'])

# 查看数据的列名
print(data.columns)

# 去掉不需要的列
# data.drop([' Timestamp', 'Flow ID', ' Source IP', ' Destination IP'], axis=1, inplace=True)
# 去除每一列中字符串的前后空格
data = data.apply(lambda x: x.str.strip() if x.dtype == 'object' else x)

# 去除每一列中字符串的多余空格
data = data.apply(lambda x: x.str.replace(r'\s+', ' ', regex=True) if x.dtype == 'object' else x)
data = data.apply(pd.to_numeric, errors='coerce')
data = data[~data.isin([np.inf, -np.inf]).any(axis=1)]
data.to_csv(r'D:\datasets\GeneratedLabelledFlows\TrafficLabelling_\newF2.csv', sep=',', index=False)
