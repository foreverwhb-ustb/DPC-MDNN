import numpy as np
import sys
import pandas as pd
import scipy.io as scio
import math
import numpy as np
from munkres import Munkres
from sklearn.manifold import Isomap
from sklearn import preprocessing
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_mutual_info_score, rand_score, fowlkes_mallows_score, adjusted_rand_score, \
    normalized_mutual_info_score, accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from scipy.sparse.csgraph._min_spanning_tree import minimum_spanning_tree
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from sklearn.decomposition import PCA
#sys.path.append("../..")
from tools.PrintFigures import PrintFigures  # 绘图操作类
from tools.FileOperator import FileOperator  # 文件操作类
from tools.FileOperatoruci import FileOperatoruci
from sklearn.datasets import make_moons
from sklearn.datasets import make_blobs
import scipy.io as scio
import time
#import tools.mintree_RDMN as mt
import DPC
from sklearn.cluster import AgglomerativeClustering
sys.path.append("../..")


class ALGORITHM:
    rcParams['font.sans-serif'] = ['SimHei']
    rcParams['axes.unicode_minus'] = False  # 处理负号问题
    pf = PrintFigures()
    fo = FileOperator()
    fouci = FileOperatoruci()
    datasetname = "test"
    # filename = '../../datasets/ED_Hexagon/dataset.csv'
    # filename = '../../datasets/VDD2.txt'
    # filename = '../../datasets/Aggregation.csv'
    # cluster_num = 7
    # filename = '../../datasets/thyroid+disease/new-thyroid.data'
    # cluster_num = 3
    # filename = '../../datasets/R15.csv'
    # cluster_num = 15
    # filename = '../../datasets/zoo/zoo.data'
    # cluster_num = 7
    # filename = '../../datasets/ecoli/ecoli.data'
    # cluster_num = 8
    # filename = '../../datasets/Compound/dataset.csv'
    # filename = "../../datasets/seeds.csv"
    # cluster_num = 3
    # filename = "../../datasets/point.txt"
    # filename = "../../datasets/grid.txt"
    # cluster_num = 3
    # filename = "../../datasets/D31.csv"
    # cluster_num = 31
    # filename = "../../datasets/Flame.csv"
    filename = "../../datasets/wdbc.csv"
    cluster_num = 2
    # filename = "../../datasets/pathbased.csv"
    # cluster_num = 3
    # 改名
    # filename = "../../datasets/ionosphere/ionosphere.data"
    # cluster_num = 2
    # filename = "../../datasets/wine.csv"
    # cluster_num = 3
    # filename = "../../datasets/shapes/flame.csv"
    # cluster_num = 2
    # filename = "../../datasets/shapes/banana-ball.csv"
    # cluster_num = 3
    # filename = "../../datasets/shapes/compound.csv"
    # cluster_num = 6
    # filename = "../../datasets/shapes/unbalance.csv"
    # cluster_num = 8
    # filename = "../../datasets/shapes/varydensity.csv"
    # cluster_num = 3
    # filename = "../../datasets/uci/iris.csv"
    # filename = "../../datasets/pima/diabetes.csv"
    # cluster_num = 2
    # filename = "../../datasets/iris.csv"
    # cluster_num = 3
    # filename = "../../datasets/glass.csv"
    # cluster_num = 7
    # filename = "../../datasets/dartboard2.csv"
    # cluster_num = 4
    # filename = "../../datasets/R15.csv"
    # filename = "../../datasets/shapes/R15.csv"
    # cluster_num = 15
    # filename = r"../../datasets/new3.csv"
    # cluster_num = 14
    # filename = r"../../datasets/BreastCancerWisconsin/data.csv"
    # cluster_num = 2
        # 将真实标签和预测标签一一映射,再计算acc
    def best_map(self, L1, L2):
        Label1 = np.unique(L1)  # 去除重复的元素，由小大大排列
        nClass1 = len(Label1)  # 标签的大小
        Label2 = np.unique(L2)
        nClass2 = len(Label2)
        # print("Label1 unique:", np.unique(L1))
        # print("Label2 unique:", np.unique(L2))
        for label in Label2:
            if label not in Label1:
                Label1 = np.append(Label1, label)
        nClass = np.maximum(nClass1, nClass2)
        G = np.zeros((nClass, nClass))
        for i in range(nClass1):
            ind_cla1 = L1 == Label1[i]
            ind_cla1 = ind_cla1.astype(float)
            for j in range(nClass2):
                ind_cla2 = L2 == Label2[j]
                ind_cla2 = ind_cla2.astype(float)
                G[i, j] = np.sum(ind_cla2 * ind_cla1)
        m = Munkres()
        index = m.compute(-G.T)
        index = np.array(index)
        c = index[:, 1]
        newL2 = np.zeros(L2.shape)
        # print(f"Label1 size: {len(Label1)}, Label2[i]: {len(Label2)}, c[i]: {len(c)}")

        for i in range(nClass2):
            newL2[L2 == Label2[i]] = Label1[c[i]]
        return newL2

    def RunAlgorithmFace(self, points, label, cluster_num):
        # points, label = self.fo.readDatawithLabel(self.filename)
        # points, label = self.fo.readDatawithLabel2(self.filename)
        # points, label = self.fo.readPoint(self.filename)
        # points = self.fo.readDatawithoutLabel(self.filename)
        # points,label = self.fo.readDatawithLabel2(self.filename)  # Flame和R15
        # points, label = self.fouci.readIris(self.filename)
        # points, label = self.fouci.readWine(self.filename)
        # points, label = self.fouci.readSegmentation(self.filename)
        # points, label = self.fouci.readDermetology(self.filename)
        # points,label = self.fouci.readSeed(self.filename)
        # points, label = self.fouci.readZoo(self.filename)
        # points, label = self.fouci.readNewthyroid(self.filename)
        # points,label = self.fouci.readControl(self.filename)
        # points, label = self.fouci.readDigits(self.filename)
        # points, label = self.fouci.readParkinsons(self.filename)
        # points, label = self.fouci.readEcoli(self.filename)
        # points, label = self.fouci.readPhishing(self.filename)
        # points, label = self.fouci.readWifi(self.filename)
        # points, label = self.fouci.readColoumn(self.filename)
        # points, label = self.fouci.readYeast(self.filename)
        # points, label = self.fouci.readPage(self.filename)
        # points, label = self.fouci.readLym(self.filename)
        # points, label = self.fouci.readAba(self.filename)
        # points, label = self.fouci.readDivorce(self.filename)
        #min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
       # points = min_max_scaler.fit_transform(points)
        size = points.shape[0]
        # 流形距离
        # dis = self.get_Distance(points)
        flag = True
        dis = self.get_Distance_liuxing(points)
        dist = np.argsort(dis, axis=1)
        start = time.time()
        r, KNN, RNN, NN = self.NN_Search(dist)
        for i in range(size):
            KNN[i].append(i)
        Den = self.get_Density(dis, NN, KNN)  #
        Rep, cores, Contain_point = self.get_Rep_and_core2(KNN, Den, NN, dis)
        #
        NND_childs = self.get_NNDchilds(cores, Rep, NN)
        GD = self.compute_similartiy(cores, Den, NND_childs, dis, Rep)
        cluster = DPC.cluster(points[cores], GD, cluster_num, Contain_point, size)
        # cluster = DPC.cluster(points[cores], GD, self.cluster_num, Contain_point, size)
        CL = np.zeros(size)
        for i in range(len(cluster.clusters_index)):
            for j in cluster.clusters_index[i]:
                CL[cores[j]] = i + 1
        CL = self.assign_points(Rep, CL)
        # self.pf.printScatter_Color(points, CL)

        end = time.time()
        print("用时", end - start)

        acc = lambda x, y: accuracy_score(x, y)
        ari = lambda x, y: adjusted_rand_score(x, y)
        ami = lambda x, y: adjusted_mutual_info_score(x, y)
        fmi = lambda x, y: fowlkes_mallows_score(x, y)
        nmi = lambda x, y: normalized_mutual_info_score(x, y)
        newL2 = self.best_map(label, CL)
        #print("指标")
       # print("%.3f,%.3f,%.3f" % (nmi(label, CL), ari(label, CL), fmi(label, CL)))
        # self.fo.writeData(self.filename, "../../datasets/res.txt")
        res = [nmi(label, CL), ari(label, CL), fmi(label, CL)]
        # 改名
        cm = confusion_matrix(label, newL2)

        # Extract FP and TN from confusion matrix
        FP = cm[0][1]
        TN = cm[0][0]
        FR = FP / (FP + TN) if (FP + TN) > 0 else 0
        self.fo.writeDataWithName("R15,lx", res, "../../datasets/res.txt", flag)
        precision = precision_score(label, newL2, average='macro')  # 多类别计算时可以使用 'micro', 'macro', 'weighted' 等
        recall = recall_score(label, newL2, average='macro')
        f1 = f1_score(label, newL2, average='macro')
        # 输出结果
        print(f"False Alarm Rate (FR): {FR:.3f}")
        print(f"Precision: {precision:.3f}")
        print(f"Recall: {recall:.3f}")
        print(f"F1-score: {f1:.3f}")
        print("%.3f,%.3f,%.3f" % (acc(label, newL2), ari(label,newL2), ami(label, newL2)))
        return CL

    def RunAlgorithm(self):
        # 间隔符为,
        points, label = self.fo.readDatawithLabel(self.filename)
        # 间隔符为\t
        # points, label = self.fo.readDatawithLabel2(self.filename)
        # points, label = self.fo.readPoint(self.filename)
        # points = self.fo.readDatawithoutLabel(self.filename)
        # points,label = self.fo.readDatawithLabel2(self.filename)  # Flame和R15
        # points, label = self.fouci.readIris(self.filename)
        # points, label = self.fouci.readWine(self.filename)
        # points, label = self.fouci.readSegmentation(self.filename)
        # points, label = self.fouci.readDermetology(self.filename)
        # points,label = self.fouci.readSeed(self.filename)
        # points, label = self.fouci.readZoo(self.filename)
        # points, label = self.fouci.readNewthyroid(self.filename)
        # points,label = self.fouci.readControl(self.filename)
        # points, label = self.fouci.readDigits(self.filename)
        # points, label = self.fouci.readParkinsons(self.filename)
        # points, label = self.fouci.readEcoli(self.filename)
        # points, label = self.fouci.readPhishing(self.filename)
        # points, label = self.fouci.readWifi(self.filename)
        # points, label = self.fouci.readColoumn(self.filename)
        # points, label = self.fouci.readYeast(self.filename)
        # points, label = self.fouci.readPage(self.filename)
        # points, label = self.fouci.readLym(self.filename)
        # points, label = self.fouci.readAba(self.filename)
        # points, label = self.fouci.readDivorce(self.filename)
        # 标准化
        min_max_scaler = preprocessing.MinMaxScaler(feature_range=(0, 1))
        points = min_max_scaler.fit_transform(points)
        size = points.shape[0]
        # PCA降维, 改
        #
        # pca = PCA(n_components=3)
        # pca.fit(points)
        # points = pca.transform(points)  # 降维后的数据
        # points = pca.inverse_transform(points)
        # 流形距离
        dis = self.get_Distance_liuxing(points)
        # dis = self.get_Distance(points)
        dist = np.argsort(dis, axis=1)
        start = time.time()
        r, KNN, RNN, NN = self.NN_Search(dist)
        # 改 最小生成树的图
        # neighbor = []
        # for i in range(len(NN)):
        #     for j in range(len(NN[i])):
        #         neighbor.append([i, NN[i][j]])
        # print(neighbor)
        #
        # print("1")
        # print(NN)
        # self.pf.print_SubCluster_MST(points, neighbor)
        for i in range(size):
            KNN[i].append(i)
        Den = self.get_Density(dis, NN, KNN)  #
        # 改 密度的图
        # self.pf.print_Den(points, Den)
        Rep, cores, Contain_point = self.get_Rep_and_core2(KNN, Den, NN, dis)
        print("中心", len(cores))
        # 改 rep的图
        # path3 = f"../../datasets/output_image/{self.datasetname}Rep.png"
        # self.pf.print_Rep_line(points, Rep, path3)
        # 计算最邻近距离的子集
        NND_childs = self.get_NNDchilds(cores, Rep, NN)
        # 计算相似性矩阵，使用核心点、密度、NND子集和代表点的信息。
        GD = self.compute_similartiy(cores, Den, NND_childs, dis, Rep)
        #执行DPC（Density Peak Clustering） 聚类算法，DPC.cluster 根据计算的相似性矩阵和核心点进行聚类。
        cluster = DPC.cluster(points[cores], GD, self.cluster_num, Contain_point, size)
        # 初始化聚类标签 CL，并将每个核心点所属的簇标签赋给 CL。
        CL = np.zeros(size)
        for i in range(len(cluster.clusters_index)):
            for j in cluster.clusters_index[i]:
                CL[cores[j]] = i + 1
        # 根据代表点 Rep 对所有点进行重新标签或重新分配簇标签。
        CL = self.assign_points(Rep, CL)

        # self.pf.print_Dcores_line_step2(points, cores, Rep)
        # self.pf.printScatter_Color(points, CL)
        # 改 merger 之后
        # path1 = f"../../datasets/output_image/{self.datasetname}Dcores.png"
        # self.pf.print_Dcores_NND(points, cores, NND_childs,path1)
        # 改名
        path2 = f"../../datasets/output_image/{self.datasetname}Scatter.png"
        self.pf.printScatter_Color_save(points, CL, path2)
        end = time.time()
        print("用时", end - start)
        print("用时", end - start)
        acc = lambda x, y: accuracy_score(x, y)
        ari = lambda x, y: adjusted_rand_score(x, y)
        ami = lambda x, y: adjusted_mutual_info_score(x, y)
        fmi = lambda x, y: fowlkes_mallows_score(x, y)
        nmi = lambda x, y: normalized_mutual_info_score(x, y)
        newL2 = self.best_map(label, CL)
        precision = precision_score(label, newL2,average='macro')  # 多类别计算时可以使用 'micro', 'macro', 'weighted' 等
        recall = recall_score(label, newL2,average='macro')
        f1 = f1_score(label, newL2,average='macro')
        cm = confusion_matrix(label, newL2)
        # Extract FP and TN from confusion matrix
        FP = cm[0][1]
        TN = cm[0][0]
        FR = FP / (FP + TN) if (FP + TN) > 0 else 0
        # 输出结果
        print(f"Precision: {precision:.3f}")
        print(f"Recall: {recall:.3f}")
        print(f"F1-score: {f1:.3f}")
        print("%.3f,%.3f,%.3f" % (acc(label, newL2), ari(label,newL2), ami(label, newL2)))
        print(f"False Alarm Rate (FR): {FR:.3f}")
        res = [nmi(label, CL), ari(label, CL), fmi(label, CL)]

        # self.fo.writeData(self.filename, "../../datasets/res.txt")
        # 改名
        self.fo.writeDataWithName("flame20,lx", res, "../../datasets/flame20.txt", liuxing=None)

    def get_Distance(self, points):
        size = points.shape[0]
        dis = np.zeros((size, size))
        for i in range(size):
            for j in range(i + 1, size):
                dd = np.linalg.norm(points[i] - points[j])
                dis[i, j] = dd
                dis[j, i] = dd
        return dis

    def get_Distance_liuxing(self, points):
        isomap = Isomap(n_components=2, n_neighbors=5, path_method="auto")
        data_2d = isomap.fit_transform(X=points)
        geo_distance_metrix = isomap.dist_matrix_  # 测地距离矩阵，shape=[n_sample,n_sample]
        # print(geo_distance_metrix)
        return geo_distance_metrix

    def NN_Search(self, dist):
        size = len(dist)
        r = 1
        flag = 0
        nb = np.zeros(size)
        count = 0
        count1 = 0
        count2 = 0
        KNN = []
        RNN = []
        for i in range(size):
            KNN.append([])
            RNN.append([])
        while flag == 0:
            count2 = 0
            NN = []
            for i in range(size):
                k = dist[i, r]
                KNN[i].append(k)
                RNN[k].append(i)
                nb[k] += 1
            for i in range(size):
                NN.append(list(set(KNN[i]) & set(RNN[i])))
                if nb[i] == 0:
                    count2 += 1
            r = r + 1
            if count1 == count2:
                count += 1
            else:
                count = 1
            if count2 == 0 or count >= 2:
                flag = 1
            count1 = count2
        neigh_bor_sum = r - 1
        return (neigh_bor_sum, KNN, RNN, NN)

    def get_Density(self, dis, NN, KNN):
        size = len(NN)
        Den = np.zeros(size)
        for i in range(size):
            for j in NN[i]:
                SNN = list(set(KNN[i]) & set(KNN[j]))
                if len(SNN) != 0:
                    Den[i] += (len(SNN)) ** 2 / ((np.sum(dis[i, SNN]) + np.sum(dis[j, SNN])) * (dis[i, j] + 0.01))
        return Den

    def get_Rep_and_core2(self, KNN, Den, NN, dis):
        size = len(Den)
        Rep = np.ones(size).astype(int) * -1
        Den_argindex = np.argsort(Den)
        cores = []
        Rep_ = []
        for i in range(size):
            Rep_.append([])
        # 在每个点的K近邻（包括自己）选择一个密度最大的点作为整个KNN的代表点，若是某点已经有了代表点，
        # 则计算已有的代表点的密度与本点的密度差和两点之间距离和的乘积当前计算的，小的为新的代表点
        for i in Den_argindex:
            max_index = KNN[i][np.argmax(Den[KNN[i]])]
            max_Den = np.max(Den[KNN[i]])
            max_index = i if Den[i] > max_Den else max_index
            for j in KNN[i]:
                Rep_[j].append(max_index)
        for i in range(size):
            s = list(set(Rep_[i]))
            max_rep = -1
            max_rep_count = 0
            for j in s:
                num = Rep_[i].count(j)
                if num > max_rep_count:
                    max_rep = j
                    max_rep_count = num
                elif num == max_rep_count:
                    if dis[i, j] * np.abs(Den[i] - Den[j]) < dis[i, max_rep] * np.abs(Den[i] - Den[max_rep]):
                        max_rep = j
                        max_rep_count = num
            Rep[i] = max_rep
        visited = np.zeros(size)
        round = 0
        for i in range(size):
            if visited[i] == 0:
                parent = i
                round += 1
                while Rep[parent] != parent:
                    visited[parent] = round
                    parent = Rep[parent]
                Rep[np.where(visited == round)[0]] = parent
        for i in range(size):
            if Rep[i] == i:
                cores.append(i)
        index = np.zeros(size).astype(int)
        k = 0
        for i in cores:
            index[i] = k
            k += 1
        delete_cores = []
        NND_childs = self.get_NNDchilds(cores, Rep, NN)
        d = {}
        k = 0
        for i in range(len(cores)):
            d[cores[i]] = k
            k += 1
        index = np.argsort(Den[cores]).astype(int)
        cores_sort = []
        for i in index:
            cores_sort.append(cores[i])
        for i in cores_sort:
            if i in delete_cores:
                continue
            else:
                for j in cores_sort:
                    if i in delete_cores:
                        break
                    if j in delete_cores:
                        continue
                    else:
                        if j in NND_childs[d[i]] or i in NND_childs[d[j]]:
                            if Den[i] < Den[j]:
                                Rep[np.where(Rep == i)[0]] = j
                                cores.remove(i)
                                delete_cores.append(i)
                                NND_childs[d[i]] = list(set(NND_childs[d[i]]).union(set(NND_childs[d[j]])))
                                break
                            if Den[i] > Den[j]:
                                Rep[np.where(Rep == j)[0]] = i
                                cores.remove(j)
                                NND_childs[d[j]] = list(set(NND_childs[d[i]]).union(set(NND_childs[d[j]])))
                                delete_cores.append(j)
                                continue

        Contain_point = []
        for i in range(len(cores)):
            Contain_point.append(np.where(Rep == cores[i])[0])
        return Rep, cores, Contain_point

    # 将每个核心点的NND_childs看做是以他们自己为代表点的点的NN近邻并集
    def get_NNDchilds(self, cores, Rep, NN):
        NND_childs = []
        for i in range(len(cores)):
            NND_child = list(np.where(Rep == cores[i])[0])
            temp = []
            if len(NND_child) != 1:
                for j in NND_child:
                    temp = set(temp).union(set(NN[j]))
            else:
                temp = set(NN[NND_child[0]]).union(set(NN[NND_child[0]]))
            NND_childs.append(list(set(NND_child).union(temp)))
        return NND_childs

    def compute_similartiy(self, cores, Den, NND_childs, dis, Rep):
        length = len(cores)
        similarity = np.zeros((length, length))
        for i in range(length):
            similarity[i, i] = 0
        maxd = 0
        for i in range(length):
            for j in range(i + 1, length):
                if maxd < dis[cores[i], cores[j]]:
                    maxd = dis[cores[i], cores[j]]
        max_p = 1
        for i in range(length):
            for j in range(i + 1, length):
                common = list(set(NND_childs[i]) & set(NND_childs[j]))

                rep_i = np.where(Rep == cores[i])[0]
                rep_j = np.where(Rep == cores[j])[0]
                mean_Deni = np.mean(Den[rep_i])
                mean_Denj = np.mean(Den[rep_j])
                if len(common) != 0:
                    dd = dis[cores[i], cores[j]] * max(len(NND_childs[i]), len(NND_childs[j])) * np.abs(
                        mean_Deni + mean_Denj) / ((len(common) ** 2) * (2 * np.sqrt(mean_Deni * mean_Denj)))

                    max_p = max(max_p, len(NND_childs[i]) * len(NND_childs[j]) / (len(common) ** 2))
                    similarity[i, j] = dd
                    similarity[j, i] = dd
        for i in range(length):
            for j in range(i + 1, length):
                common = list(set(NND_childs[i]) & set(NND_childs[j]))
                if len(common) == 0:
                    dd = (max_p) * dis[cores[i], cores[j]] * maxd
                    similarity[i, j] = dd
                    similarity[j, i] = dd
        return similarity

    # 把剩余的点分配给他们的代表点
    def assign_points(self, Rep, CL):
        size = CL.shape[0]
        for i in range(size):
            if CL[i] == 0:
                CL[i] = CL[Rep[i]]
        return CL

    def min_max(self, data):
        size, dim = data.shape
        for j in range(dim):
            max = np.max(data[:, j])
            min = np.min(data[:, j])
            for i in range(size):
                data[i, j] = (data[i, j] - min) / (max - min)
        return data


if __name__ == "__main__":
    np.set_printoptions(threshold=np.inf)
    a = ALGORITHM()
    a.RunAlgorithm()
