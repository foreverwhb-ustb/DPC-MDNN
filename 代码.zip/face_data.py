import matplotlib.pyplot as plt
import numpy as np
import os
import cv2
from skimage import color
from sklearn import preprocessing
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
import pandas as pd
import sys

# from algorithm.Dcore import Dcore
# from algorithm.DPC_face import CFSFDP
# from algorithm.HORC.my4 import my4 as HORC
# from algorithm.LDP_MST.LDPMST import LDPMST
# from algorithm.RNN_face import RNN_DBSCAN
# from algorithm.KDPC_face import KDPC
# from algorithm.SNNDPC.SNNDPC_face import SNNDPC_Face
from DPC_MDNN import ALGORITHM


def plt_show(img):
    plt.imshow(img, cmap='gray')
    plt_show()


def read_directory(directory_name):  # 返回那个路径的所有文件,每一个文件夹下的pm文件
    faces_addr = []
    for file_name in os.listdir(directory_name):
        faces_addr.append(directory_name + "/" + file_name)
    return faces_addr


def load_faces_data(path):
    faces = []
    # 数据集数目  olivetti
    # for i in range(1, 11):  # 获取每个文件夹下的图片的路径，总共有400个路径放在faces里
    # coil20
    # for i in range(1, 16):  # 获取每个文件夹下的图片的路径，总共有400个路径放在faces里
    for i in range(3, 5):  # 获取每个文件夹下的图片的路径，总共有400个路径放在faces里
        file_addr = read_directory(path + "/s" + str(i))
        for addr in file_addr:
            faces.append(addr)
    images = []
    label = []
    for index, face in enumerate(faces):
        image = cv2.imread(face, 0)
        images.append(image)
        label.append(int(index / 100 + 1))
    return images, label


def plt_show(img):
    plt.imshow(img, cmap='gray')
    plt.show()


def plot_image(images):
    fig, axes = plt.subplots(10, 10, figsize=(30, 30), subplot_kw={"xticks": [], "yticks": []})
    for i, ax in enumerate(axes.flat):
        ax.imshow(images[int(i / 10) * 10 + i % 10], cmap="gray")
    plt.show()


def PCA_images2(images, label):
    image_data = []
    label_ = []
    target_size = (100, 100)
    print("Number of images:", len(images))

    for i in range(len(images)):
        # 确保每个图像数据是一个有效的 NumPy 数组
        img = images[i]

        if img is None or not isinstance(img, np.ndarray):
            print(f"Invalid image at index {i}. Skipping...")
            continue

        # 调整图像大小到目标尺寸
        img_resized = cv2.resize(img, target_size)  # 直接对图像数据进行resize

        # 展平图像
        data = img_resized.flatten()  # 将图像展平成一维数组

        # 添加展平后的图像数据到图像数据列表
        image_data.append(data)

        # 添加对应的标签
        label_.append(label[i])

    # 将图像数据转换为 NumPy 数组
    X = np.array(image_data)

    # 使用 Pandas DataFrame 打印调试信息
    data = pd.DataFrame(X)

    # 执行 PCA 降维，保留92%的方差
    pca = PCA(0.92)
    pca.fit(X)
    PCA_data = pca.transform(X)

    # 输出保留的方差比例
    explained_variance_ratio = pca.explained_variance_ratio_.sum()
    print("Explained variance ratio:", explained_variance_ratio)

    return PCA_data, label_
def PCA_images(images, label):
    image_data = []
    label_ = []
    print("Number of images:", len(images))
    for i in range(len(images)):
        data = images[int(i / 10) * 10 + i % 10].flatten()  # 把100*112*92的三维数组变成100*10304的二维数组
        label_.append(label[int(i / 10) * 10 + i % 10])
        image_data.append(data)
    X = np.array(image_data)  # 每个图像数据降到一维后的列表
    data = pd.DataFrame(X)  # 打印的话，X可以显示列和行号的
    pca = PCA(.92)
    pca.fit(X)
    PCA_data = pca.transform(X)
    expained_variance_ratio = pca.explained_variance_ratio_.sum()  # 计算保留原始数据的多少

    # 看降到i维的保留原始数据的曲线图
    # expained_variance_ratio = []
    # for i in range(1,200):
    #     pca = PCA(n_components=i).fit(X)#构建pca降维器
    #     expained_variance_ratio.append(pca.explained_variance_ratio_.sum())#计算每次降维，所带的数据是原始数据的多少
    #     print(i,pca.explained_variance_ratio_.sum())
    # plt.plot(range(1,160),expained_variance_ratio)
    # plt.show()
    # V = pca.components_#pca中间的转换矩阵，让10304*100转换成100*98的矩阵

    return PCA_data, label_


def plot_image2(images, label, name):
    # fig,axes = plt.subplots(1,1)
    aspect = 1.
    # n = 15  # number of rows
    # m = 10  # numberof columns
    n = 10  # number of rows
    m = 10  # numberof columns
    bottom = 0.1
    left = 0.05
    top = 1. - bottom
    right = 1. - 0.18
    fisasp = (1 - bottom - (1 - top)) / float(1 - left - (1 - right))
    # widthspace, relative to subplot size
    wspace = 0  # set to zero for no spacing
    hspace = wspace / float(aspect)
    # fix the figure height
    figheight = 50  # inch
    figwidth = (m + (m - 1) * wspace) / float((n + (n - 1) * hspace) * aspect) * figheight * fisasp
    fig, axes = plt.subplots(nrows=n, ncols=m, figsize=(figwidth, figheight))
    plt.subplots_adjust(top=top, bottom=bottom, left=left, right=right,
                        wspace=wspace, hspace=hspace)
    hue_rotations = np.linspace(0, 2, 20)
    for i, ax in enumerate(axes.flat):
        image1 = color.gray2rgb(images[int(i / 10) * 10 + i % 10])
        image1 = colorize(image1, hue_rotations[int(label[i]) - 1], saturation=0.5)
        ax.imshow(image1)
        ax.axis('off')
    plt.savefig(name)
    plt.show()



def colorize(image, hue, saturation=1):
    """ Add color of the given hue to an RGB image.

    By default, set the saturation to 1 so that the colors pop!
    """
    hsv = color.rgb2hsv(image)
    hsv[:, :, 1] = saturation
    hsv[:, :, 0] = hue
    return color.hsv2rgb(hsv)


def main():
    # 数据集
    # olivetti
    # path = "../../datasets/att_faces"
    # coil20
    path = "../../datasets/voc20172"
    # path = "../../datasets/coil201"
    images, label = load_faces_data(path)
    print(images)
    # cv2.imshow('change_image', images)
    # cv2.waitkey(0)
    data, label_ = PCA_images2(images, label)
    print(data)
    print(label_)
    # dcore = Dcore()
    # dcore.RunAlgorithm(data,label_)
    # horc = HORC()
    # horc.RunAlgorithm(data,label_)
    # ldpmst = LDPMST()
    # ldpmst.RunAlgorithm(data,label_)
    # dpc = CFSFDP()
    # dpc.runAlgorithm(data,label_)
    # rnn = RNN_DBSCAN(5,data,label_)
    # rnn.Run_Algorithm()
    # kdpc = KDPC()
    # kdpc.Run_Algorithm(data,label_)
    # snndpc = SNNDPC_Face()
    # snndpc.Run_Algorithm(data, label_, 20)
    name = "../../datasets/output_image" + "/" + "voc2007.png"
    a = ALGORITHM()
    label_result = a.RunAlgorithmFace(data, label_, 2)
    print("label_result", label_result)
    # plot_image2(images, label_result, name)


if __name__ == "__main__":
    main()
